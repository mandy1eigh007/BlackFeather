# BLACKFEATHER

**Stories that actually end.**

---

## What is BLACKFEATHER?

A short-form cinematic storytelling platform built for one purpose: deliver complete, high-quality stories from beginning to end.

No filler. No fake cliffhangers. No manipulative coin systems. Just story.

---

## Why this exists

Most short drama platforms are built around artificial paywalls, stretched content, and endless cliffhangers with no resolution.

BLACKFEATHER rejects that model.

> If a story is worth starting, it is worth finishing.

---

## What makes it different

- **Complete stories only** — every saga has a beginning, middle, and ending.
- **No coins, no tricks** — simple pricing, no confusing currency systems.
- **Structured storytelling** — each saga is intentionally written and delivered.
- **Premium experience** — clean UI, cinematic presentation, no clutter.

---

## Platform structure

**Sagas** — a full story experience, equivalent to a series. Always complete (or clearly marked as in-progress).

**Chapters** — short-form video segments, 1–2 minutes each. Designed for vertical viewing with sequential auto-play.

---

## Tech stack

| Layer | Technology |
|-------|-----------|
| Framework | Next.js 14 |
| Language | TypeScript |
| Styling | Tailwind CSS |
| Auth + DB | Supabase |
| Video | Mux *(planned)* |
| Payments | Stripe *(planned)* |

---

## Project structure

```
src/
├── app/            # Pages and layouts
├── components/     # UI components
└── lib/            # Supabase client, types, queries

database/
└── schema.sql      # Full schema with RLS policies
```

---

## Getting started

```bash
# Install dependencies
npm install

# Copy environment template
cp .env.example .env.local

# Add your Supabase credentials to .env.local

# Run the dev server
npm run dev
```

Run `database/schema.sql` in your Supabase SQL Editor to set up tables.

---

## Roadmap

**Phase 1** — Core player, saga structure, Supabase integration

**Phase 2** — Stripe payments, unlock flow, user library

**Phase 3** — Original content pipeline, discovery, community

---

## Brand

Dark, minimal, cinematic. The crow symbol represents memory, intelligence, truth, and transformation.

---

## Status

Early development.

## License

Private project.

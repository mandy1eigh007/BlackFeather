import Navbar from '@/components/Navbar';
import ChapterPlayer from '@/components/ChapterPlayer';
import type { ChapterFeedItem } from '@/lib/types';

// Mock data — replace with getFeedChapters() once Supabase is connected
const MOCK_FEED: ChapterFeedItem[] = [
  {
    id: '1',
    sagaName: 'The Fallen Queen',
    sagaSlug: 'the-fallen-queen',
    title: 'The Betrayal',
    chapterNumber: 1,
    videoUrl:
      'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    isFree: true,
  },
  {
    id: '2',
    sagaName: 'The Fallen Queen',
    sagaSlug: 'the-fallen-queen',
    title: 'The Rebirth',
    chapterNumber: 2,
    videoUrl:
      'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    isFree: false,
  },
];

export default function Home() {
  const feed = MOCK_FEED;

  return (
    <main className="h-screen w-full bg-black overflow-hidden flex justify-center">
      <Navbar />
      <div className="h-full w-full max-w-md snap-y snap-mandatory overflow-y-scroll hide-scrollbar">
        {feed.map((chapter) => (
          <ChapterPlayer
            key={chapter.id}
            videoUrl={chapter.videoUrl}
            title={chapter.title}
            sagaName={chapter.sagaName}
            chapterNumber={chapter.chapterNumber}
            isFree={chapter.isFree}
          />
        ))}
      </div>
    </main>
  );
}

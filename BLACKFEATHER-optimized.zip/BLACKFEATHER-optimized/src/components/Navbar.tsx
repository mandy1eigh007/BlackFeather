'use client';

import Link from 'next/link';

export default function Navbar() {
  return (
    <nav
      className="absolute top-0 w-full max-w-md z-50 flex items-center justify-between px-4 py-3 bg-gradient-to-b from-black/90 via-black/50 to-transparent"
      aria-label="Main navigation"
    >
      <Link
        href="/"
        className="text-gold font-bold tracking-widest text-lg hover:opacity-80 transition-opacity"
      >
        BLACKFEATHER
      </Link>
      <button
        className="bg-gold text-black px-4 py-1.5 rounded-sm text-sm font-semibold shadow-md transition-all hover:opacity-90 active:scale-95 uppercase tracking-wide"
        aria-label="Unlock current saga"
      >
        Unlock Saga
      </button>
    </nav>
  );
}

'use client';

import { useRef, useState, useEffect, useCallback } from 'react';

interface ChapterPlayerProps {
  videoUrl: string;
  title: string;
  sagaName: string;
  chapterNumber: number;
  isFree: boolean;
}

export default function ChapterPlayer({
  videoUrl,
  title,
  sagaName,
  chapterNumber,
  isFree,
}: ChapterPlayerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [hasError, setHasError] = useState(false);
  const [progress, setProgress] = useState(0);

  // Pause video when scrolled out of view, play when scrolled in
  useEffect(() => {
    const video = videoRef.current;
    const container = containerRef.current;
    if (!video || !container) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (!entry.isIntersecting && !video.paused) {
          video.pause();
          setIsPlaying(false);
        }
      },
      { threshold: 0.5 }
    );

    observer.observe(container);
    return () => observer.disconnect();
  }, []);

  // Track playback progress
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const onTimeUpdate = () => {
      if (video.duration) {
        setProgress((video.currentTime / video.duration) * 100);
      }
    };

    video.addEventListener('timeupdate', onTimeUpdate);
    return () => video.removeEventListener('timeupdate', onTimeUpdate);
  }, []);

  const togglePlay = useCallback(() => {
    const video = videoRef.current;
    if (!video || hasError) return;

    if (video.paused) {
      video.play().catch(() => setHasError(true));
      setIsPlaying(true);
    } else {
      video.pause();
      setIsPlaying(false);
    }
  }, [hasError]);

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key === ' ' || e.key === 'Enter') {
        e.preventDefault();
        togglePlay();
      }
    },
    [togglePlay]
  );

  return (
    <div
      ref={containerRef}
      className="relative h-screen w-full bg-charcoal snap-start flex justify-center items-center cursor-pointer select-none"
      onClick={togglePlay}
      onKeyDown={handleKeyDown}
      role="button"
      tabIndex={0}
      aria-label={`${isPlaying ? 'Pause' : 'Play'} ${title}`}
    >
      <video
        ref={videoRef}
        src={videoUrl}
        className="h-full w-full object-cover"
        loop
        playsInline
        preload="metadata"
        onError={() => setHasError(true)}
      />

      {/* Progress bar */}
      <div className="absolute bottom-20 left-0 right-0 h-0.5 bg-white/10">
        <div
          className="h-full bg-gold transition-[width] duration-300 ease-linear"
          style={{ width: `${progress}%` }}
        />
      </div>

      {/* Chapter info overlay */}
      <div className="absolute bottom-24 left-4 right-16 text-white z-10 pointer-events-none">
        <span className="inline-block bg-charcoal/60 backdrop-blur-sm border border-gold/30 px-3 py-1 rounded-sm text-xs font-bold uppercase tracking-widest text-gold mb-2">
          {sagaName}
        </span>
        <h2 className="text-xl font-bold drop-shadow-lg tracking-wide leading-tight">
          {title}
        </h2>
        <p className="text-xs text-white/50 mt-1 tracking-wide">
          Chapter {chapterNumber} {isFree ? '· Free' : ''}
        </p>
      </div>

      {/* Play button overlay */}
      {!isPlaying && !hasError && (
        <div className="absolute inset-0 flex justify-center items-center pointer-events-none">
          <div className="bg-black/50 rounded-full p-4 border border-gold/20 backdrop-blur-sm">
            <svg
              className="w-10 h-10 text-gold ml-0.5"
              fill="currentColor"
              viewBox="0 0 24 24"
              aria-hidden="true"
            >
              <path d="M8 5v14l11-7z" />
            </svg>
          </div>
        </div>
      )}

      {/* Error state */}
      {hasError && (
        <div className="absolute inset-0 flex flex-col justify-center items-center pointer-events-none bg-black/70">
          <p className="text-white/60 text-sm">Failed to load video</p>
        </div>
      )}
    </div>
  );
}

import { supabase } from './supabase';
import type { ChapterFeedItem } from './types';

export async function getFeedChapters(): Promise<ChapterFeedItem[]> {
  const { data, error } = await supabase
    .from('chapters')
    .select(`
      id,
      chapter_number,
      title,
      video_url,
      is_free,
      sagas!inner (
        title,
        slug
      )
    `)
    .order('chapter_number', { ascending: true })
    .limit(20);

  if (error) {
    console.error('Failed to fetch chapters:', error.message);
    return [];
  }

  return (data ?? []).map((row: any) => ({
    id: row.id,
    sagaName: row.sagas.title,
    sagaSlug: row.sagas.slug,
    title: row.title,
    chapterNumber: row.chapter_number,
    videoUrl: row.video_url,
    isFree: row.is_free,
  }));
}

export async function getSagaBySlug(slug: string) {
  const { data, error } = await supabase
    .from('sagas')
    .select('*, chapters(*)')
    .eq('slug', slug)
    .single();

  if (error) {
    console.error('Failed to fetch saga:', error.message);
    return null;
  }

  return data;
}

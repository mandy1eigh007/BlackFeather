export interface Database {
  public: {
    Tables: {
      sagas: {
        Row: {
          id: string;
          title: string;
          slug: string;
          description: string | null;
          cover_image: string | null;
          is_complete: boolean;
          total_chapters: number;
          price: number;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['sagas']['Row'], 'id' | 'created_at' | 'updated_at'> & {
          id?: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database['public']['Tables']['sagas']['Insert']>;
      };
      chapters: {
        Row: {
          id: string;
          saga_id: string;
          chapter_number: number;
          title: string;
          video_url: string;
          duration_seconds: number | null;
          is_free: boolean;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['chapters']['Row'], 'id' | 'created_at'> & {
          id?: string;
          created_at?: string;
        };
        Update: Partial<Database['public']['Tables']['chapters']['Insert']>;
      };
      purchases: {
        Row: {
          id: string;
          user_id: string;
          saga_id: string;
          stripe_payment_id: string | null;
          purchased_at: string;
        };
        Insert: Omit<Database['public']['Tables']['purchases']['Row'], 'id' | 'purchased_at'> & {
          id?: string;
          purchased_at?: string;
        };
        Update: Partial<Database['public']['Tables']['purchases']['Insert']>;
      };
      watch_progress: {
        Row: {
          id: string;
          user_id: string;
          chapter_id: string;
          progress_seconds: number;
          completed: boolean;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['watch_progress']['Row'], 'id' | 'updated_at'> & {
          id?: string;
          updated_at?: string;
        };
        Update: Partial<Database['public']['Tables']['watch_progress']['Insert']>;
      };
    };
  };
}

// Convenience type aliases
export type Saga = Database['public']['Tables']['sagas']['Row'];
export type Chapter = Database['public']['Tables']['chapters']['Row'];
export type Purchase = Database['public']['Tables']['purchases']['Row'];
export type WatchProgress = Database['public']['Tables']['watch_progress']['Row'];

export interface ChapterFeedItem {
  id: string;
  sagaName: string;
  sagaSlug: string;
  title: string;
  chapterNumber: number;
  videoUrl: string;
  isFree: boolean;
}

import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        black: "#0B0B0C",
        charcoal: "#1A1A1D",
        gold: "#C2A36B",
        white: "#F5F5F3",
        crimson: "#7A1F1F",
      },
    },
  },
  plugins: [],
};
export default config;
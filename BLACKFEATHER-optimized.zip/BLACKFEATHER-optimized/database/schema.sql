-- BLACKFEATHER CORE SCHEMA
-- Run this in Supabase SQL Editor

-- ============================================================
-- TABLES
-- ============================================================

CREATE TABLE sagas (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  description TEXT,
  cover_image TEXT,
  is_complete BOOLEAN DEFAULT true,
  total_chapters INTEGER NOT NULL CHECK (total_chapters > 0),
  price NUMERIC(5, 2) NOT NULL DEFAULT 3.00 CHECK (price >= 0),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE chapters (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  saga_id UUID NOT NULL REFERENCES sagas(id) ON DELETE CASCADE,
  chapter_number INTEGER NOT NULL CHECK (chapter_number > 0),
  title TEXT NOT NULL,
  video_url TEXT NOT NULL,
  duration_seconds INTEGER,
  is_free BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(saga_id, chapter_number)
);

CREATE TABLE purchases (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  saga_id UUID NOT NULL REFERENCES sagas(id) ON DELETE CASCADE,
  stripe_payment_id TEXT,
  purchased_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, saga_id)
);

CREATE TABLE watch_progress (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  chapter_id UUID NOT NULL REFERENCES chapters(id) ON DELETE CASCADE,
  progress_seconds INTEGER DEFAULT 0,
  completed BOOLEAN DEFAULT false,
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, chapter_id)
);

-- ============================================================
-- INDEXES
-- ============================================================

CREATE INDEX idx_chapters_saga ON chapters(saga_id, chapter_number);
CREATE INDEX idx_purchases_user ON purchases(user_id);
CREATE INDEX idx_purchases_saga ON purchases(saga_id);
CREATE INDEX idx_watch_progress_user ON watch_progress(user_id);
CREATE INDEX idx_sagas_slug ON sagas(slug);

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================

ALTER TABLE sagas ENABLE ROW LEVEL SECURITY;
ALTER TABLE chapters ENABLE ROW LEVEL SECURITY;
ALTER TABLE purchases ENABLE ROW LEVEL SECURITY;
ALTER TABLE watch_progress ENABLE ROW LEVEL SECURITY;

-- Sagas: public read
CREATE POLICY "sagas_public_read" ON sagas
  FOR SELECT USING (true);

-- Chapters: public read
CREATE POLICY "chapters_public_read" ON chapters
  FOR SELECT USING (true);

-- Purchases: users see only their own
CREATE POLICY "purchases_user_read" ON purchases
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "purchases_user_insert" ON purchases
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Watch progress: users manage only their own
CREATE POLICY "progress_user_read" ON watch_progress
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "progress_user_upsert" ON watch_progress
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "progress_user_update" ON watch_progress
  FOR UPDATE USING (auth.uid() = user_id);

-- ============================================================
-- UPDATED_AT TRIGGER
-- ============================================================

CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER sagas_updated_at
  BEFORE UPDATE ON sagas
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER watch_progress_updated_at
  BEFORE UPDATE ON watch_progress
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

# Content Workflow

How sagas and chapters are created, published, and priced.

---

## Creating a saga

1. Insert a row into `sagas` with `is_published = false` (the default).
2. Set the `slug` — use the `generateUniqueSlug()` utility in `src/lib/slugs.ts`, or set it manually. Must be unique.
3. Set `total_chapters` to the planned count.
4. Set `price`.

```sql
INSERT INTO sagas (title, slug, description, total_chapters, price)
VALUES ('My Saga', 'my-saga', 'A story about...', 5, 4.99);
```

## Adding chapters

Insert chapters referencing the saga ID. Chapter numbers must be unique per saga.

```sql
INSERT INTO chapters (saga_id, chapter_number, title, video_url, duration_seconds, is_free)
VALUES
  ('saga-uuid-here', 1, 'Chapter One', 'https://...mp4', 90, true),
  ('saga-uuid-here', 2, 'Chapter Two', 'https://...mp4', 85, false);
```

**Convention:** Chapter 1 of every saga is free (`is_free = true`). This is the hook.

## Publishing

Set `is_published = true`. The `set_published_at` trigger will auto-fill `published_at`.

```sql
UPDATE sagas SET is_published = true WHERE slug = 'my-saga';
```

Once published, the saga and its chapters become visible through public queries and RLS policies.

## Unpublishing

Set `is_published = false`. The saga and all its chapters immediately disappear from public queries. Existing purchases and watch progress are unaffected.

```sql
UPDATE sagas SET is_published = false WHERE slug = 'my-saga';
```

## Soft deleting

Set `deleted_at` instead of using `DELETE`. This preserves purchase records and revenue history.

```sql
UPDATE sagas SET deleted_at = now(), is_published = false WHERE slug = 'my-saga';
```

## Pricing changes

Update the `price` column. This only affects new purchases. Existing purchases are unaffected (the `purchases` table records the transaction, not the price paid — that's in Stripe).

```sql
UPDATE sagas SET price = 5.99 WHERE slug = 'my-saga';
```

## Marking completion

When all chapters are uploaded and the saga is finished:

```sql
UPDATE sagas SET is_complete = true WHERE slug = 'my-saga';
```

Incomplete sagas can still be published — they just won't show the "Complete" badge.

---

## Current limitations

- There is no admin UI. All content management is done via SQL in the Supabase dashboard.
- There is no image upload flow. Cover images are set as URLs pointing to externally hosted images.
- Video files are referenced by URL. When Mux is integrated (Phase 2), these will become Mux asset IDs.
- Entitlements are created manually or via the purchase flow. There is no subscription billing yet.

# Media Hosting Guide

How BLACKFEATHER serves video and image content, and where to host it.

---

## How media works in this app

The app does not upload, store, or manage media files. Two database fields control all media:

- `sagas.cover_image` — a URL to a cover image (JPG/PNG/WebP)
- `chapters.video_url` — a URL to a video file (MP4)

The browser fetches the file from whatever URL you put in the database. That's the entire system. Where you host those files is up to you.

---

## Option 1: UGREEN NAS (self-hosted)

Best for: development, testing, and archival storage.

### Setup

1. Store your master files on the NAS in an organized structure:

```
/media/blackfeather/
├── the-fallen-queen/
│   ├── cover.jpg
│   ├── chapter-1.mp4
│   ├── chapter-2.mp4
│   ├── chapter-3.mp4
│   └── chapter-4.mp4
└── neon-requiem/
    ├── cover.jpg
    ├── chapter-1.mp4
    └── chapter-2.mp4
```

2. Install Nginx or Caddy on the NAS (or in a Docker container on it) to serve the files over HTTPS.

3. Point a subdomain at your NAS public IP — for example `media.blackfeather.app`.

4. Nginx config example:

```nginx
server {
    listen 443 ssl;
    server_name media.blackfeather.app;

    ssl_certificate /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;

    root /media/blackfeather;

    location / {
        # Allow video seeking (Range requests)
        add_header Accept-Ranges bytes;

        # CORS — needed if your app is on a different domain
        add_header Access-Control-Allow-Origin *;

        # Cache static files aggressively
        expires 30d;
        add_header Cache-Control "public, immutable";
    }
}
```

5. Your database URLs would then be:

```sql
UPDATE chapters
SET video_url = 'https://media.blackfeather.app/the-fallen-queen/chapter-1.mp4'
WHERE saga_id = '...' AND chapter_number = 1;
```

### Pros

- Free (no hosting costs beyond electricity and your internet plan)
- You own the hardware and the files
- Good for development — fast on local network

### Cons

- Your home upload speed is the bottleneck. Most residential connections have 10-50 Mbps upload. A single 1080p video stream uses 5-8 Mbps. You run out of bandwidth fast.
- If your internet goes down, all videos stop working.
- No adaptive bitrate — every viewer gets the same file regardless of their connection speed.
- You're responsible for security, uptime, backups, and SSL certificates.

### Verdict

Use the NAS as your permanent master archive. Serve media from it during development (especially over your local network where bandwidth doesn't matter). Do not use it as your production CDN.

---

## Option 2: Cloud object storage

Best for: early production, small audience, cost control.

### Recommended providers

| Provider | Storage | Egress | Notes |
|----------|---------|--------|-------|
| Cloudflare R2 | $0.015/GB/mo | Free | Best value — zero egress fees |
| Backblaze B2 | $0.006/GB/mo | $0.01/GB | Cheap. Pairs with Cloudflare CDN for free egress |
| AWS S3 | $0.023/GB/mo | $0.09/GB | Expensive egress. Avoid unless you're already on AWS |

### Setup (Cloudflare R2 example)

1. Create an R2 bucket in your Cloudflare dashboard.
2. Upload your video and image files.
3. Enable public access on the bucket (or use a custom domain).
4. Your URLs will look like: `https://media.blackfeather.app/the-fallen-queen/chapter-1.mp4`

You can use `rclone` to sync files from your UGREEN NAS to R2:

```bash
# Install rclone on your NAS or a computer with access to both
rclone sync /media/blackfeather/ r2:blackfeather-media/
```

5. Put the R2 URLs in your database.

### Pros

- Cheap — a full saga (10 chapters × 2 min × ~50MB each = 500MB) costs about $0.008/month to store on R2.
- Zero egress on R2 means you pay nothing when users watch videos.
- Reliable — 99.999% uptime, no maintenance.
- Fast — Cloudflare's CDN caches files at edge locations worldwide.

### Cons

- Still serving raw MP4 files — no adaptive bitrate streaming.
- Users on slow connections get buffering, not a lower-quality smooth stream.
- No built-in analytics on who watched what.

### Verdict

This is the sweet spot for early production. Cheap, reliable, and scales to thousands of viewers without any infrastructure work. Start here when you're ready for real users.

---

## Option 3: Mux (professional video platform)

Best for: production at scale, premium viewing experience.

### What Mux does

You upload a video file. Mux transcodes it into multiple quality levels (360p, 720p, 1080p, etc.), generates an HLS adaptive bitrate stream, hosts it on a global CDN, and gives you a playback ID.

When a viewer watches, Mux automatically serves the best quality for their connection. Slow mobile data gets 360p that plays smoothly. Fast wifi gets 1080p. The viewer never buffers.

### Pricing

- Storage: ~$0.007 per minute of video stored per month
- Delivery: ~$0.007 per minute of video watched
- A 2-minute chapter watched 1,000 times = about $14

For short-form content this is very reasonable.

### Integration with BLACKFEATHER

The `video_url` field in the database would change from a direct MP4 URL to a Mux playback URL:

```
https://stream.mux.com/{PLAYBACK_ID}.m3u8
```

The `<video>` tag in `ChapterPlayer.tsx` would need an HLS player library. The standard choice is `hls.js`:

```tsx
// Future ChapterPlayer change (not implemented yet)
import Hls from 'hls.js';

useEffect(() => {
  const video = videoRef.current;
  if (!video) return;

  if (video.canPlayType('application/vnd.apple.mpegurl')) {
    // Safari has native HLS support
    video.src = videoUrl;
  } else if (Hls.isSupported()) {
    const hls = new Hls();
    hls.loadSource(videoUrl);
    hls.attachMedia(video);
    return () => hls.destroy();
  }
}, [videoUrl]);
```

### Signed URLs (content protection)

For paid content, Mux supports signed playback URLs that expire after a set time. This prevents users from sharing direct video links. The signing happens server-side:

1. User requests a chapter → your server checks entitlement
2. Server generates a signed Mux URL (valid for e.g. 2 hours)
3. Client receives the signed URL and plays it
4. URL expires — cannot be reused or shared

This is the correct way to protect paid video content. Raw MP4 URLs (Options 1 and 2) can always be copied from the browser's network tab and shared.

### Env vars (already in .env.example)

```
MUX_TOKEN_ID=your_token_id
MUX_TOKEN_SECRET=your_token_secret
```

### Verdict

This is the production endgame. When BLACKFEATHER has paying users watching paid content, Mux is where the video should live. The adaptive streaming, content protection, and analytics are worth the cost.

---

## Recommended path

| Phase | Media hosting | Why |
|-------|--------------|-----|
| Now (development) | UGREEN NAS on local network | Free, instant, zero setup |
| Phase 1 (first real users) | Cloudflare R2 | Cheap, reliable, zero egress |
| Phase 2 (paid content) | Mux | Adaptive streaming, signed URLs, analytics |

Your UGREEN NAS stays in the picture permanently as your master archive. Every video file you produce should live there first. Then you sync/upload to whichever delivery platform you're using.

---

## File format recommendations

### Video

- Format: MP4 container, H.264 codec, AAC audio
- Resolution: 1080×1920 (vertical 9:16) for chapter content
- Bitrate: 4-8 Mbps for 1080p (Mux will re-encode anyway, so don't over-compress your masters)
- Duration: 1-2 minutes per chapter
- File size: roughly 30-80 MB per chapter at this spec

### Cover images

- Format: WebP preferred (smaller files), JPG as fallback
- Resolution: 1080×1620 (2:3 portrait ratio) for saga covers
- File size: keep under 500KB — these load on the feed and saga pages

### Naming convention

Use slugs to match your database:

```
{saga-slug}/cover.webp
{saga-slug}/chapter-{number}.mp4
```

Example: `the-fallen-queen/chapter-1.mp4`

---

## Current state of the app

Right now, `chapters.video_url` accepts any URL that serves a valid MP4 file. The `<video>` element in `ChapterPlayer.tsx` uses native browser playback — no HLS, no adaptive bitrate, no signed URLs. This is correct for Phase 1. The Mux integration (HLS player, signed URLs, server-side signing) is a Phase 2 task.

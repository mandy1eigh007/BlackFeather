# BLACKFEATHER — Complete Changelog

Every change made from the original uploaded code through V3, organized by version.

---

## V1 → V2: Initial optimization

### database/schema.sql

**Added `slug TEXT UNIQUE NOT NULL` to sagas.** Enables clean URLs like `/saga/the-fallen-queen` instead of UUID-based routes.

**Added `CHECK` constraints.** `total_chapters > 0`, `chapter_number > 0`, `price >= 0`. Prevents inserting invalid data at the database level.

**Added `UNIQUE(saga_id, chapter_number)` to chapters.** Prevents duplicate chapter numbers within the same saga.

**Added `NOT NULL` to foreign keys** on chapters.saga_id, purchases.user_id, purchases.saga_id. The original allowed orphan records.

**Added `duration_seconds` to chapters.** Needed for UI display and progress tracking.

**Added `stripe_payment_id` to purchases.** Required for Phase 2 refund/dispute handling.

**Added `updated_at` to sagas** with auto-update trigger.

**Created `watch_progress` table.** Tracks user_id, chapter_id, progress_seconds, completed. Powers "resume where you left off."

**Added indexes** on saga_id, user_id, slug, and chapter lookups.

**Added Row Level Security policies.** Public read on sagas/chapters, user-scoped read/write on purchases and watch_progress.

### V2 additional changes (fix list)

**Added `is_published BOOLEAN DEFAULT false` and `published_at TIMESTAMPTZ` to sagas.** Prevents draft content from leaking to public queries.

**Added `deleted_at TIMESTAMPTZ` to sagas.** Enables soft-delete — preserves purchase records and revenue history instead of destroying them with CASCADE.

**Changed purchases.saga_id to `ON DELETE SET NULL`** instead of CASCADE. If a saga is hard-deleted, purchase records survive.

**Added `last_watched_at TIMESTAMPTZ` to watch_progress.** Powers "Continue Watching" sorted by recency.

**Created `entitlements` table.** Unified access layer for purchases, subscriptions, promo codes, and admin grants. Source is CHECK-constrained to ('purchase', 'subscription', 'promo', 'admin_grant').

**Hardened RLS policies.** Sagas public read now requires `is_published = true AND deleted_at IS NULL`. Chapters public read uses a subquery to check parent saga's published/deleted status.

**Added triggers.** `set_published_at` auto-fills published_at when is_published flips to true. `update_last_watched_at` auto-updates on watch_progress changes.

### src/lib/supabase.ts

**V1:** Created typed client with `createClient<Database>()`. Added runtime throw if env vars missing.

**V2:** No change from V1.

### src/lib/types.ts

**V1:** Created full Database interface with Row/Insert/Update types for all tables. Added convenience aliases (Saga, Chapter, etc.). Added ChapterFeedItem interface.

**V2:** Added is_published, published_at, deleted_at to Saga types. Added last_watched_at to WatchProgress. Added Entitlement type. Added `QueryResult<T>` discriminated union for typed error returns. Added SagaDetail interface. Made purchases.saga_id nullable (matching SET NULL cascade). Added durationSeconds to ChapterFeedItem.

### src/lib/queries.ts

**V1:** Created getFeedChapters() and getSagaBySlug() with Supabase joins.

**V2:** Rewrote to return `QueryResult<T>` instead of silently returning empty arrays. Added is_published and deleted_at filters as defense-in-depth on all queries. Added requireAuth() guard. Added checkEntitlement(), upsertWatchProgress(), getContinueWatching() for authenticated operations.

### src/lib/slugs.ts

**V2 new file.** Pure slugify() function plus generateUniqueSlug() that checks for collisions against the database.

### src/components/ChapterPlayer.tsx

**V1:** Added IntersectionObserver (auto-pause on scroll-out), progress bar, error handling, preload="metadata", keyboard accessibility (Space/Enter), aria-labels.

**V2:** Split `hasError` into `hasLoadError` and `playBlocked`. NotAllowedError (autoplay policy) now shows "Tap to play" hint instead of "Failed to load video." Added durationSeconds prop with loadedmetadata fallback. Added formatDuration display. Added isFinite() check on video.duration.

### src/components/Navbar.tsx

**V1:** Wrapped logo in Link, added aria-labels, added active:scale-95 feedback.

**V2:** No change from V1.

### src/components/FeedContent.tsx

**V2 new file.** Client component that owns the data fetching lifecycle. Checks env vars to decide mock vs. real data. Manages loading/error/empty/ready states. Contains the mock feed data (moved from page.tsx).

### src/components/FeedStates.tsx

**V2 new file.** FeedLoading (spinner), FeedEmpty ("No Stories Yet"), FeedError (error message + Try Again button).

### src/app/page.tsx

**V1:** Replaced inline mock data with typed ChapterFeedItem[], fixed HTTP→HTTPS on video URLs, added sagaSlug/chapterNumber/isFree to mock data.

**V2:** Simplified to just render Navbar + FeedContent. All data logic moved to FeedContent.

### src/app/layout.tsx

**V1:** Separated viewport export from metadata (Next.js 14 pattern). Added themeColor, Open Graph tags.

**V2:** Removed `userScalable: false` for accessibility.

### src/app/globals.css

**V1:** Removed unused font-family declaration. Renamed scrollbar-hide class to `.hide-scrollbar`. Added body overflow:hidden.

**V2:** No change from V1.

### src/app/saga/[slug]/page.tsx

**V2 new file.** Saga detail page with cover image, description, chapter list (with duration and lock icons), completion badge, unlock button, and full loading/error/not-found states.

### tailwind.config.ts

**V1:** Unchanged from original.

**V2:** No change from V1.

### Other V2 additions

- `.env.example` — added Stripe webhook secret, Mux token placeholders
- `.gitignore` — created (original had none)
- `database/seed.sql` — 3 sample sagas (2 published, 1 unpublished draft for RLS testing), 9 chapters
- `docs/CONTENT_WORKFLOW.md` — full admin workflow: creating, publishing, unpublishing, soft-deleting, pricing, completion
- `src/__tests__/queries.test.ts` — working slugify() tests + todo stubs for query tests
- `package.json` — added `typecheck` script

---

## V2 → V3: Bug fixes and hardening

### src/lib/supabase.ts — REWRITTEN

**The problem:** The V2 client threw an Error at import time if env vars were missing. Every file that imported it (queries.ts, slugs.ts, FeedContent.tsx) crashed during module initialization — before any mock-data fallback code could run. Cloning the repo and running `npm run dev` without a .env.local file crashed the app.

**The fix:** Replaced with lazy initialization pattern. Two exports:
- `getSupabase()` — returns the client or null if env vars are missing. Never throws.
- `requireSupabase()` — returns the client or throws. Used inside function bodies, never at module scope.

No code runs at import time. The client is created once on first call and cached.

### src/lib/queries.ts — REWRITTEN

**The problem:** All functions called `supabase.xxx()` using a module-level import of the old throwing client.

**The fix:** Every function now calls `requireSupabase()` at the start of its own body. The import is `import { requireSupabase } from './supabase'` — a function reference, not an eager initialization.

### src/lib/slugs.ts — FIXED

**The problem:** Same module-level import crash as queries.ts.

**The fix:** Changed `import { supabase }` to `import { requireSupabase }`. Added `const supabase = requireSupabase()` inside generateUniqueSlug() function body.

### src/components/FeedStates.tsx — FIXED

**The problem:** Missing `'use client'` directive. FeedError uses `onClick` and `window.location.reload()` — both are client-side APIs. Without the directive, `next build` fails with a server component error.

**The fix:** Added `'use client'` at the top of the file.

### src/components/FeedContent.tsx — REWRITTEN

**The problem:** Checked `process.env.NEXT_PUBLIC_SUPABASE_URL` at module scope to decide mock vs. real mode. This is unreliable — NEXT_PUBLIC vars aren't always available at module evaluation time in all Next.js contexts. Also, no try/catch around getFeedChapters(), which could throw from requireSupabase().

**The fix:** Replaced module-scope env check with `getSupabase()` call inside useEffect (runtime check). Added try/catch around the data fetch. Import changed from `supabase` to `getSupabase` from the new lazy client.

### src/app/globals.css — FIXED

**The problem:** `body { overflow: hidden }` was global. This was correct for the feed page (which has its own scroll container), but it broke the saga detail page — users couldn't scroll through the chapter list. Any future page that needed scrolling would also be broken.

**The fix:** Removed `overflow: hidden` from body. The feed page already has `overflow-hidden` on its own `<main>` element, so feed behavior is unchanged.

### src/components/Navbar.tsx — FIXED

**The problem:** The "Unlock Saga" button had no onClick handler. Tapping it did nothing. A dead button in the UI makes the app feel broken.

**The fix:** Added state-managed toast. Tapping the button shows "Payments coming soon" for 2.5 seconds with a fade-in animation, then disappears.

### src/app/saga/[slug]/page.tsx — REWRITTEN

**The problem:** (1) Unlock button was dead — same issue as Navbar. (2) No try/catch on data fetch. (3) Not-found detection only checked for the word "row" in the error string — fragile. (4) Used unescaped apostrophes in JSX. (5) No check for missing Supabase client (would crash in mock mode).

**The fix:** Added toast on unlock button with "Payments coming soon." Added try/catch. Added PGRST116 error code check for not-found (Supabase's actual error code for .single() with zero rows). Replaced apostrophes with `&apos;` entities. Added getSupabase() check — returns not_found gracefully when Supabase isn't configured.

### src/components/ChapterPlayer.tsx — UPDATED

**The problem:** Saga name badge was a `<span>` — no way for users to navigate from the feed to a saga's detail page.

**The fix:** Added `sagaSlug` prop. Converted saga name badge to a `<Link href={/saga/${sagaSlug}}>` with `pointer-events-auto` (needed because the parent overlay is `pointer-events-none`) and `stopPropagation()` (so clicking the link doesn't also toggle video play/pause).

### tailwind.config.ts — UPDATED

Added `fade-in` keyframe animation (translateY + opacity) for the toast UI on Navbar and saga detail page.

### New files in V3

**src/app/error.tsx** — Route-level error boundary. Catches unhandled errors within the layout. Shows branded error message + "Try Again" button that calls Next.js reset(). Without this, any render error = white screen.

**src/app/global-error.tsx** — Layout-level error boundary. Catches errors in the root layout itself (rare but catastrophic). Must include its own `<html>` and `<body>` tags since the layout is the thing that crashed. Uses inline hex colors instead of Tailwind theme (since the layout/Tailwind might be the thing that failed).

**src/app/not-found.tsx** — Custom 404 page. Shows branded "404" with "Back to Feed" link. Without this, users see the default Next.js 404 page which doesn't match the app's design.

**src/app/loading.tsx** — Root loading state. Shows a spinner during route transitions (e.g., navigating from feed to saga detail). Without this, the page hangs with no feedback while the new route loads.

**src/app/saga/[slug]/loading.tsx** — Saga-specific loading state. Same spinner, scoped to the saga route.

**docs/MEDIA_HOSTING.md** — Complete guide covering: UGREEN NAS setup with Nginx config, Cloudflare R2 setup with rclone sync, Mux integration with HLS player code and signed URLs, recommended migration path (NAS → R2 → Mux), file format specs for video and cover images, naming conventions.

---

## File inventory (V3 final — 30 files)

```
.env.example
.gitignore
README.md
database/schema.sql
database/seed.sql
docs/CONTENT_WORKFLOW.md
docs/MEDIA_HOSTING.md
next-env.d.ts
package.json
postcss.config.mjs
tailwind.config.ts
tsconfig.json
src/app/error.tsx
src/app/global-error.tsx
src/app/globals.css
src/app/layout.tsx
src/app/loading.tsx
src/app/not-found.tsx
src/app/page.tsx
src/app/saga/[slug]/loading.tsx
src/app/saga/[slug]/page.tsx
src/components/ChapterPlayer.tsx
src/components/FeedContent.tsx
src/components/FeedStates.tsx
src/components/Navbar.tsx
src/lib/queries.ts
src/lib/slugs.ts
src/lib/supabase.ts
src/lib/types.ts
src/__tests__/queries.test.ts
```

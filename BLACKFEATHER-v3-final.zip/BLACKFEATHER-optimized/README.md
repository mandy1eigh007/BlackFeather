# BLACKFEATHER

**Stories that actually end.**

---

## What is BLACKFEATHER?

A short-form cinematic storytelling platform built for one purpose: deliver complete, high-quality stories from beginning to end.

No filler. No fake cliffhangers. No manipulative coin systems. Just story.

---

## Why this exists

Most short drama platforms are built around artificial paywalls, stretched content, and endless cliffhangers with no resolution.

BLACKFEATHER rejects that model.

> If a story is worth starting, it is worth finishing.

---

## What makes it different

- **Complete stories only** — every saga has a beginning, middle, and ending.
- **No coins, no tricks** — simple pricing, no confusing currency systems.
- **Structured storytelling** — each saga is intentionally written and delivered.
- **Premium experience** — clean UI, cinematic presentation, no clutter.

---

## Platform structure

**Sagas** — a full story experience, equivalent to a series. Always complete (or clearly marked as in-progress). Each saga has a detail page at `/saga/[slug]` with cover art, description, chapter list, and unlock button.

**Chapters** — short-form video segments, 1–2 minutes each. Designed for vertical viewing with sequential snap-scroll, auto-pause when off-screen, and progress tracking.

---

## Tech stack

| Layer | Technology |
|-------|-----------|
| Framework | Next.js 14 |
| Language | TypeScript |
| Styling | Tailwind CSS |
| Auth + DB | Supabase |
| Video | Mux *(planned)* |
| Payments | Stripe *(planned)* |

---

## Project structure

```
src/
├── app/
│   ├── page.tsx              # Feed (home)
│   ├── layout.tsx            # Root layout
│   ├── globals.css           # Global styles
│   ├── loading.tsx           # Route transition spinner
│   ├── error.tsx             # Error boundary (within layout)
│   ├── global-error.tsx      # Error boundary (layout-level crash)
│   ├── not-found.tsx         # Custom 404
│   └── saga/[slug]/
│       ├── page.tsx          # Saga detail page
│       └── loading.tsx       # Saga route loading state
├── components/
│   ├── ChapterPlayer.tsx     # Video player with snap-scroll
│   ├── FeedContent.tsx       # Feed data lifecycle (loading/error/empty/ready)
│   ├── FeedStates.tsx        # Loading, empty, error UI components
│   └── Navbar.tsx            # Top navigation
├── lib/
│   ├── supabase.ts           # Lazy Supabase client (never crashes on missing env)
│   ├── types.ts              # Database types + query result types
│   ├── queries.ts            # All data fetching (typed errors, auth guards)
│   └── slugs.ts              # Slug generation + collision handling
└── __tests__/
    └── queries.test.ts       # Test stubs (vitest)

database/
├── schema.sql                # Full schema with RLS policies
└── seed.sql                  # Sample data for local development

docs/
├── CHANGELOG.md              # Complete V1→V3 changelog
├── CONTENT_WORKFLOW.md       # How to create, publish, and price content
└── MEDIA_HOSTING.md          # Video/image hosting guide (NAS, R2, Mux)
```

---

## Getting started

```bash
# Install dependencies
npm install

# Copy environment template
cp .env.example .env.local

# Add your Supabase credentials to .env.local

# Run schema in Supabase SQL Editor
# database/schema.sql

# (Optional) Load sample data
# database/seed.sql

# Start dev server
npm run dev
```

The app works without Supabase credentials — it falls back to mock data automatically. Once you add real credentials, it switches to live queries.

---

## Scripts

```bash
npm run dev        # Start development server
npm run build      # Production build
npm run lint       # ESLint
npm run typecheck  # TypeScript type checking
```

---

## Database

The schema includes Row Level Security policies. Key rules:

- Public users can only read **published, non-deleted** sagas and their chapters.
- Unpublished sagas and soft-deleted sagas are invisible to public queries.
- Authenticated users can only read/write their own purchases and watch progress.
- An `entitlements` table provides a unified access layer for purchases, subscriptions, promo codes, and admin grants.

See `docs/CONTENT_WORKFLOW.md` for how to create and publish content.
See `docs/MEDIA_HOSTING.md` for where to host video and image files.
See `docs/CHANGELOG.md` for the complete history of every change made to this codebase.

---

## Roadmap

**Phase 1** — Core player, saga structure, Supabase integration

**Phase 2** — Stripe payments, unlock flow, user library, Mux video streaming

**Phase 3** — Original content pipeline, discovery, community

---

## Brand

Dark, minimal, cinematic. The crow symbol represents memory, intelligence, truth, and transformation.

---

## Status

Early development.

## License

Private project.

-- BLACKFEATHER CORE SCHEMA
-- Run this in Supabase SQL Editor
-- Version: 2.0

-- ============================================================
-- TABLES
-- ============================================================

CREATE TABLE sagas (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  description TEXT,
  cover_image TEXT,
  is_complete BOOLEAN DEFAULT true,
  is_published BOOLEAN DEFAULT false,
  published_at TIMESTAMPTZ,
  total_chapters INTEGER NOT NULL CHECK (total_chapters > 0),
  price NUMERIC(5, 2) NOT NULL DEFAULT 3.00 CHECK (price >= 0),
  deleted_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE chapters (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  saga_id UUID NOT NULL REFERENCES sagas(id) ON DELETE CASCADE,
  chapter_number INTEGER NOT NULL CHECK (chapter_number > 0),
  title TEXT NOT NULL,
  video_url TEXT NOT NULL,
  duration_seconds INTEGER,
  is_free BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(saga_id, chapter_number)
);

-- NOTE: saga_id uses SET NULL instead of CASCADE.
-- If a saga is hard-deleted, purchase records survive for refund/revenue history.
-- In normal operations, use soft-delete (set deleted_at) on sagas instead.
CREATE TABLE purchases (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  saga_id UUID REFERENCES sagas(id) ON DELETE SET NULL,
  stripe_payment_id TEXT,
  purchased_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, saga_id)
);

CREATE TABLE watch_progress (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  chapter_id UUID NOT NULL REFERENCES chapters(id) ON DELETE CASCADE,
  progress_seconds INTEGER DEFAULT 0,
  completed BOOLEAN DEFAULT false,
  last_watched_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, chapter_id)
);

-- Entitlements: unified access layer.
-- Covers purchases, subscriptions, promo codes, and admin grants.
-- The purchases table handles Stripe transaction records.
-- This table answers: "can this user access this saga right now?"
CREATE TABLE entitlements (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  saga_id UUID NOT NULL REFERENCES sagas(id) ON DELETE CASCADE,
  source TEXT NOT NULL CHECK (source IN ('purchase', 'subscription', 'promo', 'admin_grant')),
  granted_at TIMESTAMPTZ DEFAULT now(),
  expires_at TIMESTAMPTZ,
  is_active BOOLEAN DEFAULT true,
  UNIQUE(user_id, saga_id, source)
);

-- ============================================================
-- INDEXES
-- ============================================================

CREATE INDEX idx_sagas_slug ON sagas(slug);
CREATE INDEX idx_sagas_published ON sagas(is_published, deleted_at);
CREATE INDEX idx_chapters_saga ON chapters(saga_id, chapter_number);
CREATE INDEX idx_purchases_user ON purchases(user_id);
CREATE INDEX idx_purchases_saga ON purchases(saga_id);
CREATE INDEX idx_watch_progress_user ON watch_progress(user_id);
CREATE INDEX idx_watch_progress_last ON watch_progress(user_id, last_watched_at DESC);
CREATE INDEX idx_entitlements_user ON entitlements(user_id, is_active);
CREATE INDEX idx_entitlements_saga ON entitlements(saga_id);

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================

ALTER TABLE sagas ENABLE ROW LEVEL SECURITY;
ALTER TABLE chapters ENABLE ROW LEVEL SECURITY;
ALTER TABLE purchases ENABLE ROW LEVEL SECURITY;
ALTER TABLE watch_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE entitlements ENABLE ROW LEVEL SECURITY;

-- Sagas: public can ONLY read published, non-deleted sagas
CREATE POLICY "sagas_public_read" ON sagas
  FOR SELECT USING (
    is_published = true AND deleted_at IS NULL
  );

-- Chapters: public can ONLY read chapters whose parent saga is published and not deleted
CREATE POLICY "chapters_public_read" ON chapters
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM sagas
      WHERE sagas.id = chapters.saga_id
        AND sagas.is_published = true
        AND sagas.deleted_at IS NULL
    )
  );

-- Purchases: authenticated users see only their own
CREATE POLICY "purchases_user_read" ON purchases
  FOR SELECT USING (auth.uid() = user_id);

-- Purchases: authenticated users can only insert their own
CREATE POLICY "purchases_user_insert" ON purchases
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Watch progress: authenticated users read only their own
CREATE POLICY "progress_user_read" ON watch_progress
  FOR SELECT USING (auth.uid() = user_id);

-- Watch progress: authenticated users insert only their own
CREATE POLICY "progress_user_insert" ON watch_progress
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Watch progress: authenticated users update only their own
CREATE POLICY "progress_user_update" ON watch_progress
  FOR UPDATE USING (auth.uid() = user_id);

-- Entitlements: authenticated users read only their own
CREATE POLICY "entitlements_user_read" ON entitlements
  FOR SELECT USING (auth.uid() = user_id);

-- ============================================================
-- TRIGGERS
-- ============================================================

CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER sagas_updated_at
  BEFORE UPDATE ON sagas
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER watch_progress_updated_at
  BEFORE UPDATE ON watch_progress
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Auto-set published_at when is_published changes to true
CREATE OR REPLACE FUNCTION set_published_at()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.is_published = true AND (OLD.is_published = false OR OLD.is_published IS NULL) THEN
    NEW.published_at = now();
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER sagas_set_published_at
  BEFORE UPDATE ON sagas
  FOR EACH ROW EXECUTE FUNCTION set_published_at();

-- Auto-update last_watched_at when progress changes
CREATE OR REPLACE FUNCTION update_last_watched_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.last_watched_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER watch_progress_last_watched
  BEFORE UPDATE ON watch_progress
  FOR EACH ROW EXECUTE FUNCTION update_last_watched_at();

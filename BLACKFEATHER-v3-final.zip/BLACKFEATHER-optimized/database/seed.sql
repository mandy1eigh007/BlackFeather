-- BLACKFEATHER SEED DATA
-- Run this AFTER schema.sql in Supabase SQL Editor
-- Creates sample sagas and chapters for local development

-- ============================================================
-- SAMPLE SAGAS
-- ============================================================

INSERT INTO sagas (id, title, slug, description, is_complete, is_published, total_chapters, price)
VALUES
  (
    '00000000-0000-0000-0000-000000000001',
    'The Fallen Queen',
    'the-fallen-queen',
    'A queen betrayed by her own court must reclaim her throne — or burn it to the ground.',
    true,
    true,
    4,
    4.99
  ),
  (
    '00000000-0000-0000-0000-000000000002',
    'Neon Requiem',
    'neon-requiem',
    'In a city that never sleeps, a detective chases a ghost that might be himself.',
    false,
    true,
    3,
    3.99
  ),
  (
    '00000000-0000-0000-0000-000000000003',
    'Hollow Earth',
    'hollow-earth',
    'Draft saga — should NOT appear in public queries.',
    false,
    false,
    2,
    2.99
  );

-- ============================================================
-- SAMPLE CHAPTERS
-- ============================================================

-- The Fallen Queen (4 chapters, chapter 1 is free)
INSERT INTO chapters (saga_id, chapter_number, title, video_url, duration_seconds, is_free)
VALUES
  ('00000000-0000-0000-0000-000000000001', 1, 'The Betrayal',
   'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
   15, true),
  ('00000000-0000-0000-0000-000000000001', 2, 'The Rebirth',
   'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
   15, false),
  ('00000000-0000-0000-0000-000000000001', 3, 'The War Council',
   'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
   15, false),
  ('00000000-0000-0000-0000-000000000001', 4, 'The Reckoning',
   'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4',
   15, false);

-- Neon Requiem (3 chapters, chapter 1 is free)
INSERT INTO chapters (saga_id, chapter_number, title, video_url, duration_seconds, is_free)
VALUES
  ('00000000-0000-0000-0000-000000000002', 1, 'Static',
   'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4',
   15, true),
  ('00000000-0000-0000-0000-000000000002', 2, 'Feedback',
   'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4',
   15, false),
  ('00000000-0000-0000-0000-000000000002', 3, 'Signal Lost',
   'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4',
   15, false);

-- Hollow Earth (unpublished draft — 2 chapters, should NOT appear publicly)
INSERT INTO chapters (saga_id, chapter_number, title, video_url, duration_seconds, is_free)
VALUES
  ('00000000-0000-0000-0000-000000000003', 1, 'The Descent',
   'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/VolkswagenGTIReview.mp4',
   15, true),
  ('00000000-0000-0000-0000-000000000003', 2, 'The Core',
   'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4',
   15, false);

-- ============================================================
-- VERIFICATION QUERIES
-- Run these after seeding to confirm RLS works correctly.
-- They should be run as the anon role (default in SQL Editor).
-- ============================================================

-- Should return 2 sagas (The Fallen Queen, Neon Requiem). NOT Hollow Earth.
-- SELECT * FROM sagas;

-- Should return 7 chapters. NOT the 2 Hollow Earth chapters.
-- SELECT * FROM chapters;

/**
 * Generate a URL-safe slug from a title.
 *
 * Strategy:
 *  - Lowercase, strip non-alphanumeric (except hyphens/spaces)
 *  - Collapse whitespace/hyphens into single hyphens
 *  - Trim leading/trailing hyphens
 *
 * Collision handling:
 *  - Call generateUniqueSlug() which checks Supabase and appends -2, -3, etc.
 */

import { requireSupabase } from './supabase';

export function slugify(title: string): string {
  return title
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/[\s-]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

export async function generateUniqueSlug(title: string): Promise<string> {
  const base = slugify(title);
  if (!base) {
    // Fallback for titles that are entirely non-latin characters
    return `saga-${Date.now()}`;
  }

  const supabase = requireSupabase();

  // Check if base slug is available
  const { data } = await supabase
    .from('sagas')
    .select('slug')
    .like('slug', `${base}%`);

  const existing = new Set((data ?? []).map((row: any) => row.slug));

  if (!existing.has(base)) return base;

  // Append incrementing suffix
  let i = 2;
  while (existing.has(`${base}-${i}`)) {
    i++;
  }

  return `${base}-${i}`;
}

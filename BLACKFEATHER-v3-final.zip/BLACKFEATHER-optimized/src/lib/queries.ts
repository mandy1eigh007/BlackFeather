import { requireSupabase } from './supabase';
import type { ChapterFeedItem, SagaDetail, QueryResult } from './types';

// ============================================================
// AUTH
// ============================================================

export async function requireAuth(): Promise<QueryResult<string>> {
  const supabase = requireSupabase();
  const {
    data: { user },
    error,
  } = await supabase.auth.getUser();

  if (error || !user) {
    return { data: null, error: 'Not authenticated' };
  }

  return { data: user.id, error: null };
}

// ============================================================
// PUBLIC QUERIES
// ============================================================

export async function getFeedChapters(): Promise<QueryResult<ChapterFeedItem[]>> {
  const supabase = requireSupabase();

  const { data, error } = await supabase
    .from('chapters')
    .select(
      `
      id,
      chapter_number,
      title,
      video_url,
      is_free,
      duration_seconds,
      sagas!inner (
        title,
        slug,
        is_published,
        deleted_at
      )
    `
    )
    .eq('sagas.is_published', true)
    .is('sagas.deleted_at', null)
    .order('chapter_number', { ascending: true })
    .limit(20);

  if (error) {
    return { data: null, error: error.message };
  }

  const items: ChapterFeedItem[] = (data ?? []).map((row: any) => ({
    id: row.id,
    sagaName: row.sagas.title,
    sagaSlug: row.sagas.slug,
    title: row.title,
    chapterNumber: row.chapter_number,
    videoUrl: row.video_url,
    isFree: row.is_free,
    durationSeconds: row.duration_seconds,
  }));

  return { data: items, error: null };
}

export async function getSagaBySlug(
  slug: string
): Promise<QueryResult<SagaDetail>> {
  const supabase = requireSupabase();

  const { data, error } = await supabase
    .from('sagas')
    .select(
      `
      id,
      title,
      slug,
      description,
      cover_image,
      is_complete,
      total_chapters,
      price,
      chapters (
        id,
        chapter_number,
        title,
        video_url,
        is_free,
        duration_seconds
      )
    `
    )
    .eq('slug', slug)
    .eq('is_published', true)
    .is('deleted_at', null)
    .single();

  if (error) {
    return { data: null, error: error.message };
  }

  const chapters = ((data as any).chapters ?? [])
    .sort((a: any, b: any) => a.chapter_number - b.chapter_number)
    .map((ch: any) => ({
      id: ch.id,
      chapterNumber: ch.chapter_number,
      title: ch.title,
      videoUrl: ch.video_url,
      isFree: ch.is_free,
      durationSeconds: ch.duration_seconds,
    }));

  const saga: SagaDetail = {
    id: data.id,
    title: data.title,
    slug: data.slug,
    description: data.description,
    coverImage: data.cover_image,
    isComplete: data.is_complete,
    totalChapters: data.total_chapters,
    price: data.price,
    chapters,
  };

  return { data: saga, error: null };
}

// ============================================================
// AUTHENTICATED QUERIES
// ============================================================

export async function checkEntitlement(
  sagaId: string
): Promise<QueryResult<boolean>> {
  const supabase = requireSupabase();
  const auth = await requireAuth();
  if (auth.error) return { data: null, error: auth.error };

  const { data, error } = await supabase
    .from('entitlements')
    .select('id')
    .eq('user_id', auth.data)
    .eq('saga_id', sagaId)
    .eq('is_active', true)
    .maybeSingle();

  if (error) {
    return { data: null, error: error.message };
  }

  return { data: data !== null, error: null };
}

export async function upsertWatchProgress(
  chapterId: string,
  progressSeconds: number,
  completed: boolean
): Promise<QueryResult<void>> {
  const supabase = requireSupabase();
  const auth = await requireAuth();
  if (auth.error) return { data: null, error: auth.error };

  const { error } = await supabase.from('watch_progress').upsert(
    {
      user_id: auth.data,
      chapter_id: chapterId,
      progress_seconds: progressSeconds,
      completed,
    },
    { onConflict: 'user_id,chapter_id' }
  );

  if (error) {
    return { data: null, error: error.message };
  }

  return { data: undefined, error: null };
}

export async function getContinueWatching(): Promise<
  QueryResult<{ chapterId: string; progressSeconds: number }[]>
> {
  const supabase = requireSupabase();
  const auth = await requireAuth();
  if (auth.error) return { data: null, error: auth.error };

  const { data, error } = await supabase
    .from('watch_progress')
    .select('chapter_id, progress_seconds')
    .eq('user_id', auth.data)
    .eq('completed', false)
    .order('last_watched_at', { ascending: false })
    .limit(10);

  if (error) {
    return { data: null, error: error.message };
  }

  const items = (data ?? []).map((row: any) => ({
    chapterId: row.chapter_id,
    progressSeconds: row.progress_seconds,
  }));

  return { data: items, error: null };
}

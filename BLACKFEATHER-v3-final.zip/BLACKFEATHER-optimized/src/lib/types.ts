export interface Database {
  public: {
    Tables: {
      sagas: {
        Row: {
          id: string;
          title: string;
          slug: string;
          description: string | null;
          cover_image: string | null;
          is_complete: boolean;
          is_published: boolean;
          published_at: string | null;
          total_chapters: number;
          price: number;
          deleted_at: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['sagas']['Row'], 'id' | 'created_at' | 'updated_at' | 'deleted_at' | 'published_at'> & {
          id?: string;
          created_at?: string;
          updated_at?: string;
          deleted_at?: string | null;
          published_at?: string | null;
        };
        Update: Partial<Database['public']['Tables']['sagas']['Insert']>;
      };
      chapters: {
        Row: {
          id: string;
          saga_id: string;
          chapter_number: number;
          title: string;
          video_url: string;
          duration_seconds: number | null;
          is_free: boolean;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['chapters']['Row'], 'id' | 'created_at'> & {
          id?: string;
          created_at?: string;
        };
        Update: Partial<Database['public']['Tables']['chapters']['Insert']>;
      };
      purchases: {
        Row: {
          id: string;
          user_id: string;
          saga_id: string | null;
          stripe_payment_id: string | null;
          purchased_at: string;
        };
        Insert: Omit<Database['public']['Tables']['purchases']['Row'], 'id' | 'purchased_at'> & {
          id?: string;
          purchased_at?: string;
        };
        Update: Partial<Database['public']['Tables']['purchases']['Insert']>;
      };
      watch_progress: {
        Row: {
          id: string;
          user_id: string;
          chapter_id: string;
          progress_seconds: number;
          completed: boolean;
          last_watched_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['watch_progress']['Row'], 'id' | 'updated_at' | 'last_watched_at'> & {
          id?: string;
          updated_at?: string;
          last_watched_at?: string;
        };
        Update: Partial<Database['public']['Tables']['watch_progress']['Insert']>;
      };
      entitlements: {
        Row: {
          id: string;
          user_id: string;
          saga_id: string;
          source: 'purchase' | 'subscription' | 'promo' | 'admin_grant';
          granted_at: string;
          expires_at: string | null;
          is_active: boolean;
        };
        Insert: Omit<Database['public']['Tables']['entitlements']['Row'], 'id' | 'granted_at'> & {
          id?: string;
          granted_at?: string;
        };
        Update: Partial<Database['public']['Tables']['entitlements']['Insert']>;
      };
    };
  };
}

// Convenience type aliases
export type Saga = Database['public']['Tables']['sagas']['Row'];
export type Chapter = Database['public']['Tables']['chapters']['Row'];
export type Purchase = Database['public']['Tables']['purchases']['Row'];
export type WatchProgress = Database['public']['Tables']['watch_progress']['Row'];
export type Entitlement = Database['public']['Tables']['entitlements']['Row'];

// Query result wrapper — never silently swallow errors (Fix #4)
export type QueryResult<T> =
  | { data: T; error: null }
  | { data: null; error: string };

export interface ChapterFeedItem {
  id: string;
  sagaName: string;
  sagaSlug: string;
  title: string;
  chapterNumber: number;
  videoUrl: string;
  isFree: boolean;
  durationSeconds: number | null;
}

export interface SagaDetail {
  id: string;
  title: string;
  slug: string;
  description: string | null;
  coverImage: string | null;
  isComplete: boolean;
  totalChapters: number;
  price: number;
  chapters: {
    id: string;
    chapterNumber: number;
    title: string;
    videoUrl: string;
    isFree: boolean;
    durationSeconds: number | null;
  }[];
}

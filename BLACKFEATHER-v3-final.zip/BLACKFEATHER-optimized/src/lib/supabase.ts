import { createClient, SupabaseClient } from '@supabase/supabase-js';
import type { Database } from './types';

let _client: SupabaseClient<Database> | null = null;

/**
 * Lazily initializes the Supabase client.
 * Returns null if env vars are missing (mock mode).
 * Never throws at import time.
 */
export function getSupabase(): SupabaseClient<Database> | null {
  if (_client) return _client;

  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  if (!url || !key) return null;

  _client = createClient<Database>(url, key);
  return _client;
}

/**
 * Returns the Supabase client or throws.
 * Use this in code paths that REQUIRE a real connection (queries, auth).
 */
export function requireSupabase(): SupabaseClient<Database> {
  const client = getSupabase();
  if (!client) {
    throw new Error(
      'Supabase not configured. Add NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY to .env.local'
    );
  }
  return client;
}

'use client';

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <div className="min-h-screen flex flex-col justify-center items-center bg-black px-8 text-center">
      <p className="text-crimson text-lg font-bold tracking-widest uppercase mb-2">
        Something Went Wrong
      </p>
      <p className="text-white/40 text-sm leading-relaxed mb-6 max-w-xs">
        {error.message || 'An unexpected error occurred.'}
      </p>
      <button
        onClick={reset}
        className="bg-gold text-black px-5 py-2 rounded-sm text-sm font-semibold uppercase tracking-wide transition-all hover:opacity-90 active:scale-95"
      >
        Try Again
      </button>
    </div>
  );
}

import Navbar from '@/components/Navbar';
import FeedContent from '@/components/FeedContent';

export default function Home() {
  return (
    <main className="h-screen w-full bg-black overflow-hidden flex justify-center">
      <Navbar />
      <FeedContent />
    </main>
  );
}

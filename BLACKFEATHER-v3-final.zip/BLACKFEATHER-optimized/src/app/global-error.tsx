'use client';

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <html lang="en">
      <body className="bg-[#0B0B0C] text-[#F5F5F3] antialiased">
        <div className="min-h-screen flex flex-col justify-center items-center px-8 text-center">
          <p className="text-[#7A1F1F] text-lg font-bold tracking-widest uppercase mb-2">
            Something Went Wrong
          </p>
          <p className="text-white/40 text-sm leading-relaxed mb-6 max-w-xs">
            {error.message || 'An unexpected error occurred.'}
          </p>
          <button
            onClick={reset}
            className="bg-[#C2A36B] text-[#0B0B0C] px-5 py-2 rounded-sm text-sm font-semibold uppercase tracking-wide transition-all hover:opacity-90 active:scale-95"
          >
            Try Again
          </button>
        </div>
      </body>
    </html>
  );
}

import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="min-h-screen flex flex-col justify-center items-center bg-black px-8 text-center">
      <p className="text-gold text-5xl font-bold tracking-widest mb-4">404</p>
      <p className="text-white/60 text-sm leading-relaxed mb-6 max-w-xs">
        This page doesn't exist. The story you're looking for may have been
        removed or hasn't been published yet.
      </p>
      <Link
        href="/"
        className="bg-gold text-black px-5 py-2 rounded-sm text-sm font-semibold uppercase tracking-wide transition-all hover:opacity-90 active:scale-95"
      >
        Back to Feed
      </Link>
    </div>
  );
}

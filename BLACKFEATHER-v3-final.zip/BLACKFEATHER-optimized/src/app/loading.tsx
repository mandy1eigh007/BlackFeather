export default function Loading() {
  return (
    <div className="min-h-screen flex justify-center items-center bg-black">
      <div className="w-8 h-8 border-2 border-gold/30 border-t-gold rounded-full animate-spin" />
    </div>
  );
}

import './globals.css';
import type { Metadata, Viewport } from 'next';

export const metadata: Metadata = {
  title: 'BLACKFEATHER',
  description: 'Stories that actually end.',
  openGraph: {
    title: 'BLACKFEATHER',
    description: 'Short-form cinematic stories. Complete. No filler. No tricks.',
    type: 'website',
  },
};

export const viewport: Viewport = {
  themeColor: '#0B0B0C',
  width: 'device-width',
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="bg-black text-white antialiased">{children}</body>
    </html>
  );
}

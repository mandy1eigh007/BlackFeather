'use client';

import { useEffect, useState } from 'react';
import ChapterPlayer from '@/components/ChapterPlayer';
import { FeedLoading, FeedEmpty, FeedError } from '@/components/FeedStates';
import { getSupabase } from '@/lib/supabase';
import { getFeedChapters } from '@/lib/queries';
import type { ChapterFeedItem } from '@/lib/types';

// Fallback mock data — used when Supabase is not connected.
// Remove this block once your .env.local has real credentials.
const MOCK_FEED: ChapterFeedItem[] = [
  {
    id: '1',
    sagaName: 'The Fallen Queen',
    sagaSlug: 'the-fallen-queen',
    title: 'The Betrayal',
    chapterNumber: 1,
    videoUrl:
      'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    isFree: true,
    durationSeconds: null,
  },
  {
    id: '2',
    sagaName: 'The Fallen Queen',
    sagaSlug: 'the-fallen-queen',
    title: 'The Rebirth',
    chapterNumber: 2,
    videoUrl:
      'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    isFree: false,
    durationSeconds: null,
  },
];

type FeedState =
  | { status: 'loading' }
  | { status: 'error'; message: string }
  | { status: 'empty' }
  | { status: 'ready'; chapters: ChapterFeedItem[] };

export default function FeedContent() {
  const [state, setState] = useState<FeedState>({ status: 'loading' });

  useEffect(() => {
    // Check at runtime, not at module scope
    const client = getSupabase();

    if (!client) {
      // No Supabase configured — use mock data
      setState({ status: 'ready', chapters: MOCK_FEED });
      return;
    }

    let cancelled = false;

    async function load() {
      try {
        const result = await getFeedChapters();

        if (cancelled) return;

        if (result.error) {
          setState({ status: 'error', message: result.error });
        } else if (result.data.length === 0) {
          setState({ status: 'empty' });
        } else {
          setState({ status: 'ready', chapters: result.data });
        }
      } catch (err) {
        if (cancelled) return;
        setState({
          status: 'error',
          message: err instanceof Error ? err.message : 'Unknown error',
        });
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, []);

  if (state.status === 'loading') return <FeedLoading />;
  if (state.status === 'error') return <FeedError message={state.message} />;
  if (state.status === 'empty') return <FeedEmpty />;

  return (
    <div className="h-full w-full max-w-md snap-y snap-mandatory overflow-y-scroll hide-scrollbar">
      {state.chapters.map((chapter) => (
        <ChapterPlayer
          key={chapter.id}
          videoUrl={chapter.videoUrl}
          title={chapter.title}
          sagaName={chapter.sagaName}
          sagaSlug={chapter.sagaSlug}
          chapterNumber={chapter.chapterNumber}
          isFree={chapter.isFree}
          durationSeconds={chapter.durationSeconds}
        />
      ))}
    </div>
  );
}

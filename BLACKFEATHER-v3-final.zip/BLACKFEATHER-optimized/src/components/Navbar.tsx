'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function Navbar() {
  const [showToast, setShowToast] = useState(false);

  const handleUnlock = () => {
    setShowToast(true);
    setTimeout(() => setShowToast(false), 2500);
  };

  return (
    <nav
      className="absolute top-0 w-full max-w-md z-50 flex items-center justify-between px-4 py-3 bg-gradient-to-b from-black/90 via-black/50 to-transparent"
      aria-label="Main navigation"
    >
      <Link
        href="/"
        className="text-gold font-bold tracking-widest text-lg hover:opacity-80 transition-opacity"
      >
        BLACKFEATHER
      </Link>
      <button
        onClick={handleUnlock}
        className="bg-gold text-black px-4 py-1.5 rounded-sm text-sm font-semibold shadow-md transition-all hover:opacity-90 active:scale-95 uppercase tracking-wide"
        aria-label="Unlock current saga"
      >
        Unlock Saga
      </button>

      {/* Toast */}
      {showToast && (
        <div className="absolute top-14 right-4 bg-charcoal border border-gold/20 text-white/70 text-xs px-3 py-2 rounded-sm shadow-lg animate-fade-in">
          Payments coming soon
        </div>
      )}
    </nav>
  );
}
